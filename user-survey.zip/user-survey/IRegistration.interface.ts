export interface IRegistration {
    firstName: string;
    lastName: string;
    emailId: string;
    mobile: string;
    password: string;
}