export interface ILogin {
   
    emailId: string;
    
    password: string;
}