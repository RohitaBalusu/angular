
//
import { Component, OnInit } from '@angular/core';
import { Survey } from '../survey.model';
import { ActivatedRoute, Router } from '@angular/router';
import { SurveyService } from '../survey.service';

@Component({
  selector: 'app-update-survey',
  templateUrl: './update-survey.component.html',
  styleUrls: ['./update-survey.component.css']
})
export class UpdateSurveyComponent implements OnInit {

  id: number;
  survey: Survey;

  constructor(private route: ActivatedRoute,private router: Router,
    private surveyService: SurveyService) { }

  ngOnInit() {
    this.survey = new Survey();

    this.id = this.route.snapshot.params['id'];
    
    this.surveyService.getSurvey(this.id)
      .subscribe(data => {
        console.log(data)
        this.survey = data;
      }, error => console.log(error));
  }

  updateSurvey() {
    this.surveyService.updateSurvey(this.id, this.survey)
      .subscribe(data => {
        console.log(data);
        this.survey = new Survey();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateSurvey();    
  }

  gotoList() {
    this.router.navigate(['/surveys']);
  }
}