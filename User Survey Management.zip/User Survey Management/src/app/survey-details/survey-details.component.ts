
import { Survey } from '../survey.model';
import { Component, OnInit, Input } from '@angular/core';
import { SurveyService } from '../survey.service';
import { SurveyListComponent } from '../survey-list/survey-list.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-survey-details',
  templateUrl: './survey-details.component.html',
  styleUrls: ['./survey-details.component.css']
})
export class SurveyDetailsComponent implements OnInit {

  id: number;
  survey: Survey;

  constructor(private route: ActivatedRoute,private router: Router,
    private surveyService: SurveyService) { }

  ngOnInit() {
    this.survey = new Survey();

    this.id = this.route.snapshot.params['id'];
    
    this.surveyService.getSurvey(this.id)
      .subscribe(data => {
        console.log(data)
        this.survey = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['surveys']);
  }
}