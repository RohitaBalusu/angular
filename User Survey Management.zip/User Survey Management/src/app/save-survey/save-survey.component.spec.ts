import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveSurveyComponent } from './save-survey.component';

describe('SaveSurveyComponent', () => {
  let component: SaveSurveyComponent;
  let fixture: ComponentFixture<SaveSurveyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveSurveyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
