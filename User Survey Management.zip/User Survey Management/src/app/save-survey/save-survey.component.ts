
import { SurveyService } from '../survey.service';
import { Survey } from '../survey.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-save-survey',
  templateUrl: './save-survey.component.html',
  styleUrls: ['./save-survey.component.css']
})
export class SaveSurveyComponent implements OnInit {

  survey: Survey = new Survey();
  submitted = false;

  constructor(private surveyService: SurveyService,
    private router: Router) { }

  ngOnInit() {
  }

  newSurvey(): void {
    this.submitted = false;
    this.survey = new Survey();
  }

  save() {
    this.surveyService
    .saveSurvey(this.survey).subscribe(data => {
      console.log(data)
      this.survey = new Survey();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/surveys']);
  }
}