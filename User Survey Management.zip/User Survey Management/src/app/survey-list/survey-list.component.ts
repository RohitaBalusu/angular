

import { SurveyDetailsComponent } from '../survey-details/survey-details.component';
import { Observable } from "rxjs";
import { SurveyService } from '../survey.service';
import { Survey } from "../survey.model";
import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

@Component({
  selector: 'app-survey-list',
  templateUrl: './survey-list.component.html',
  styleUrls: ['./survey-list.component.css']
})
export class SurveyListComponent implements OnInit {

  surveys: Observable<Survey[]>;

  constructor(private surveyService: SurveyService,
    private router: Router) {}

  ngOnInit() {
  
    this.reloadData();
  }

  reloadData() {
    this.surveys = this.surveyService.getSurveys();

  }

  deleteSurvey(id: number) {
    this.surveyService.deleteSurvey(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  surveyDetails(id: number){
    this.router.navigate(['details', id]);
  }
}
