import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './survey.model';


//import { User } from './user.model';
/*
  registerUser(user: User) {
    const body: User = {
      emailId: user.emailId,
      password: user.password,
      mobile: user.mobile,
      firstName: user.firstName,
      lastName: user.lastName
    }
*/
@Injectable({
  providedIn: 'root'
})
export class SurveyService {

  private baseUrl = 'http://localhost:9093/survey';

  constructor(private http: HttpClient) { }

  getSurvey(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  saveSurvey(survey: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, survey);
  }

  updateSurvey(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteSurvey(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getSurveys(): Observable<any> {
    //console.log('Hi')
    return this.http.get(`${this.baseUrl}`, { responseType: 'text' as 'json'});
  }
  //
  getUserClaims(){
    return  this.http.get(this.baseUrl+'/api/GetUserClaims');
   }
}